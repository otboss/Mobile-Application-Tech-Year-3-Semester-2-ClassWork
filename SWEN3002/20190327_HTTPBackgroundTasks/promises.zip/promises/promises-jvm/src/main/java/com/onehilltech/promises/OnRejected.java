package com.onehilltech.promises;

public interface OnRejected
{
  Promise onRejected (Throwable reason);
}
