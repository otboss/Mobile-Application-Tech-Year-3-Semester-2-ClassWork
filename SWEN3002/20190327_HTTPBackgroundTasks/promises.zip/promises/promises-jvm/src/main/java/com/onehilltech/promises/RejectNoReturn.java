package com.onehilltech.promises;

public interface RejectNoReturn
{
  void rejectNoReturn (Throwable reason);
}
